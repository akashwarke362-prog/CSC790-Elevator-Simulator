#ifndef BUILDINGMANAGER_H
#define BUILDINGMANAGER_H

#include <vector>
#include <string>
#include "ElevatorController.h"

// Coordinates all elevators in the building.
class BuildingManager
{
public:
    BuildingManager(int floors);

    void configureElevators(int count, const std::vector<int> &initFloors,
                            const std::vector<int> &travelTimes,
                            const std::vector<int> &capacities,
                            const std::vector<Algorithm> &algos);

    void setRequests(const std::vector<Request> &reqs);
    void assignRequestsGreedy();
    void runAll(const std::string &logPrefix);
    void printSummary() const;

private:
    int totalFloors;
    std::vector<ElevatorController> elevators;
    std::vector<Request> allRequests;
};

#endif // BUILDINGMANAGER_H
