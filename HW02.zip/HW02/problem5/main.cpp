/**
 * CSC232 - Data Structures
 * Missouri State University, Fall 2025
 *
 * @file    main.cpp
 * @author  Akash Warke
 * @brief   Reads integers from a file into a dynamically growing array, then
 *          builds a frequency table with consecutive frequency differences.
 *          Prints the original array and the frequency table.
 *          Note: std::vector is intentionally not used.
 *          Imp Note : - use test.txt file as inputfile
 */

#include <iostream>
#include <fstream>

static void resize_int_array( int *& arr, int & cap, int new_cap )
{
    int * tmp{ new int[ new_cap ] };
    for ( int i{ 0 }; i < cap; ++i )
    {
        tmp[ i ] = arr[ i ];
    }
    delete [ ] arr;
    arr = tmp;
    cap = new_cap;
}

static void insertion_sort( int * a, int n )
{
    for ( int i{ 1 }; i < n; ++i )
    {
        int key{ a[ i ] };
        int j{ i - 1 };
        while ( j >= 0 && a[ j ] > key )
        {
            a[ j + 1 ] = a[ j ];
            --j;
        }
        a[ j + 1 ] = key;
    }
}

int main( )
{
    std::string filename;
    std::cout << "Enter input filename: ";
    std::getline( std::cin, filename );

    std::ifstream fin( filename );
    if ( !fin )
    {
        std::cerr << "Error: cannot open file.\n";
        return 1;
    }

    int cap{ 8 };
    int sz{ 0 };
    int * data{ new int[ cap ] };

    int v;
    while ( fin >> v )
    {
        if ( sz == cap )
        {
            resize_int_array( data, cap, cap * 2 );
        }
        data[ sz++ ] = v;
    }
    fin.close( );

    if ( cap != sz )
    {
        int * exact{ new int[ sz ] };
        for ( int i{ 0 }; i < sz; ++i )
        {
            exact[ i ] = data[ i ];
        }
        delete [ ] data;
        data = exact;
        cap = sz;
    }

    std::cout << "Array size: " << sz << "\nValues:\n";
    for ( int i{ 0 }; i < sz; ++i )
    {
        std::cout << data[ i ] << ( ( i + 1 == sz ) ? '\n' : ' ' );
    }

    int * sorted{ new int[ sz ] };
    for ( int i{ 0 }; i < sz; ++i ) sorted[ i ] = data[ i ];
    insertion_sort( sorted, sz );

    int unique_count{ ( sz > 0 ) ? 1 : 0 };
    for ( int i{ 1 }; i < sz; ++i )
    {
        if ( sorted[ i ] != sorted[ i - 1 ] ) ++unique_count;
    }

    int rows{ unique_count }, cols{ 3 };
    int ** table{ new int *[ rows ] };
    for ( int r{ 0 }; r < rows; ++r ) table[ r ] = new int[ cols ];

    int r{ 0 };
    for ( int i{ 0 }; i < sz; )
    {
        int val{ sorted[ i ] };
        int count{ 1 };
        int j{ i + 1 };
        while ( j < sz && sorted[ j ] == val )
        {
            ++count;
            ++j;
        }
        table[ r ][ 0 ] = val;
        table[ r ][ 1 ] = count;
        ++r;
        i = j;
    }

    for ( int i{ 0 }; i < rows; ++i )
    {
        int prev{ ( i == 0 ) ? 0 : table[ i - 1 ][ 1 ] };
        table[ i ][ 2 ] = table[ i ][ 1 ] - prev;
    }

    std::cout << "\nValue  Freq  Diff\n";
    for ( int i{ 0 }; i < rows; ++i )
    {
        std::cout << table[ i ][ 0 ] << "     " << table[ i ][ 1 ]
                  << "     " << table[ i ][ 2 ] << '\n';
    }

    for ( int i{ 0 }; i < rows; ++i ) delete [ ] table[ i ];
    delete [ ] table;
    delete [ ] sorted;
    delete [ ] data;
    return 0;
}
