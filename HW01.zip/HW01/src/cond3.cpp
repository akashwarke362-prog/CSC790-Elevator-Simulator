/**
 * Elevator Simulator — Logic 3: Move in one direction (directional sweep)
 * Author: Akash Warke
 */

#include "ElevetorSimulator.h"

void cond3(struct Request reqs[], int n, int total_floors,
              int travel_time, int initial_floor, int capacity)
{
    (void)total_floors; (void)capacity;

    FILE* log = fopen("log3_directional_sweep.txt", "w");
    if (!log) { fprintf(stderr, "Could not open log3_directional_sweep.txt\n"); return; }

    int served[MAX_REQUESTS] = {0};
    int remaining = n;

    int earliest = INT_MAX;
    for (int i = 0; i < n; ++i) if (reqs[i].request_time < earliest) earliest = reqs[i].request_time;

    int current_time  = (earliest == INT_MAX) ? 0 : earliest;
    int current_floor = initial_floor;
    int dir = 1; /* 1 = up, -1 = down */

    fprintf(log, "=== directional_sweep LOG ===\n");
    fprintf(log, "initial_floor=%d travel_time_per_floor=%d capacity=%d\n\n",
            initial_floor, travel_time, capacity);

    int total_travel = 0;

    while (remaining > 0) {
        int pick = -1, best_dist = INT_MAX;

        /* Prefer nearest pickup in current direction */
        for (int i = 0; i < n; ++i) {
            if (!served[i] && reqs[i].request_time <= current_time) {
                int df = reqs[i].start_floor - current_floor;
                if ((dir == 1 && df >= 0) || (dir == -1 && df <= 0)) {
                    int dist = abs_i(df);
                    if (dist < best_dist) { best_dist = dist; pick = i; }
                }
            }
        }

        /* If none in current direction, check opposite direction and flip if found */
        if (pick == -1) {
            int alt = -1, alt_dist = INT_MAX;
            for (int i = 0; i < n; ++i) {
                if (!served[i] && reqs[i].request_time <= current_time) {
                    int dist = abs_i(reqs[i].start_floor - current_floor);
                    if (dist < alt_dist) { alt_dist = dist; alt = i; }
                }
            }
            if (alt != -1) {
                dir = (reqs[alt].start_floor >= current_floor) ? 1 : -1;
                pick = alt;
            }
        }

        if (pick == -1) {
            /* Still nothing available: jump time to the next arrival */
            int next_t = min_unserved_request_time(reqs, served, n);
            if (next_t < 0) break;
            fprintf(log, "[t=%d] idle waiting until t=%d (no available requests)\n",
                    current_time, next_t);
            current_time = next_t;
            continue;
        }

        struct Request r = reqs[pick];

        int to_pick  = abs_i(r.start_floor - current_floor);
        int move1    = to_pick * travel_time;
        current_time += move1;
        total_travel += move1;

        fprintf(log, "[t=%d] pickup Req#%d at floor %d (from %d, dir=%s, travel=%d)\n",
                current_time, r.id, r.start_floor, current_floor, (dir==1?"UP":"DOWN"), move1);

        int to_drop  = abs_i(r.dest_floor - r.start_floor);
        int move2    = to_drop * travel_time;
        current_time += move2;
        total_travel += move2;

        int turnaround = current_time - r.request_time;

        fprintf(log, "[t=%d] drop   Req#%d at floor %d (travel=%d) | per-request time=%d\n",
                current_time, r.id, r.dest_floor, move2, turnaround);

        current_floor = r.dest_floor;
        served[pick]  = 1;
        --remaining;
    }

    int makespan = (n > 0 && earliest != INT_MAX) ? (current_time - earliest) : 0;
    fprintf(log, "\nTOTAL travel_time=%d  |  MAKESPAN=%d\n", total_travel, makespan);

    fclose(log);
    printf("directional sweep finished. See log3_directional_sweep.txt\n");
}
