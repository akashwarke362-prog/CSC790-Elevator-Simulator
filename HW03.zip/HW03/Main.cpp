#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>

#include "BuildingManager.h"
#include "SimUtils.h"

static Algorithm randomAlgorithm()
{
    int r = std::rand() % 3;
    return (r == 0 ? Algorithm::FCFS : r == 1 ? Algorithm::SSTF : Algorithm::SWEEP);
}

int main()
{
    std::srand(static_cast<unsigned>(std::time(nullptr)));

    int floors, numElevators;
    std::cout << "Enter total floors: ";
    std::cin >> floors;
    std::cout << "Enter number of elevators: ";
    std::cin >> numElevators;

    std::vector<int> initFloors(numElevators), travelTimes(numElevators), capacities(numElevators);
    std::vector<Algorithm> algos(numElevators);

    for (int i = 0; i < numElevators; ++i)
    {
        std::cout << "Elevator " << i + 1 << " initial floor: ";
        std::cin >> initFloors[i];
        std::cout << "Capacity: ";
        std::cin >> capacities[i];
        std::cout << "Travel time per floor (s): ";
        std::cin >> travelTimes[i];
        algos[i] = randomAlgorithm();
    }

    int nReq, seed;
    std::cout << "Enter number of requests: ";
    std::cin >> nReq;
    std::cout << "Enter RNG seed (0=random): ";
    std::cin >> seed;
    if (seed == 0) seed = static_cast<int>(std::time(nullptr));

    std::vector<Request> reqs;
    SimUtils::generateRequests(reqs, nReq, floors, seed);

    BuildingManager building(floors);
    building.configureElevators(numElevators, initFloors, travelTimes, capacities, algos);
    building.setRequests(reqs);
    building.assignRequestsGreedy();

    std::string prefix = "ElevatorLog";
    building.runAll(prefix);
    building.printSummary();

    std::cout << "\nLogs saved as " << prefix << "_elevator*.txt\n";
    return 0;
}
