/**
 * Elevator Simulator — Utilities
 * Author: Akash Warke
 */

#include "ElevetorSimulator.h"

static int rand_int(int lo, int hi) {
    if (hi < lo) { int t = lo; lo = hi; hi = t; }
    return lo + (rand() % (hi - lo + 1));
}

void generate_requests(struct Request a[], int n, int total_floors) {
    for (int i = 0; i < n; ++i) {
        a[i].id = i + 1;
        a[i].request_time = rand_int(0, 30);                 /* random arrival 0..30s */
        a[i].start_floor  = rand_int(0, total_floors - 1);
        a[i].dest_floor   = rand_int(0, total_floors - 1);
        if (a[i].dest_floor == a[i].start_floor) {
            a[i].dest_floor = (a[i].dest_floor + 1) % total_floors;
        }
    }
}

void print_requests(const struct Request a[], int n) {
    printf("\nGenerated Requests:\n");
    printf("ID  Time  Start  Dest\n");
    for (int i = 0; i < n; ++i) {
        printf("%-3d %-5d %-6d %-6d\n",
               a[i].id, a[i].request_time, a[i].start_floor, a[i].dest_floor);
    }
}

void copy_requests(const struct Request src[], struct Request dst[], int n) {
    for (int i = 0; i < n; ++i) dst[i] = src[i];
}

int abs_i(int x) { return x < 0 ? -x : x; }

void sort_by_request_time(struct Request a[], int n) {
    for (int i = 0; i < n - 1; ++i) {
        for (int j = i + 1; j < n; ++j) {
            if (a[j].request_time < a[i].request_time) {
                struct Request t = a[i]; a[i] = a[j]; a[j] = t;
            }
        }
    }
}

int min_unserved_request_time(const struct Request a[], const int served[], int n) {
    int best = INT_MAX;
    for (int i = 0; i < n; ++i) {
        if (!served[i] && a[i].request_time < best) best = a[i].request_time;
    }
    return (best == INT_MAX) ? -1 : best;
}
