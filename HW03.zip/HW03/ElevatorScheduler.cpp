#include "ElevatorScheduler.h"
#include "SimUtils.h"
#include <cstdio>
#include <climits>

using namespace SimUtils;

// Utility for log header
static void writeHeader(FILE *log, const char *title,
                        int initFloor, int travel, int cap)
{
    std::fprintf(log,
                 "=== %s ===\ninitial_floor=%d travel_time_per_floor=%d capacity=%d\n\n",
                 title, initFloor, travel, cap);
}

// ==========================================================
// 1️⃣ FCFS (First-Come, First-Served)
// ==========================================================
RunStats ElevatorScheduler::runFCFS(std::vector<Request> requests,
                                    int totalFloors, int travelTime,
                                    int initFloor, int cap,
                                    const std::string &file)
{
    (void)totalFloors; (void)cap;
    RunStats S;
    FILE *log = std::fopen(file.c_str(), "w");
    if (!log) return S;
    writeHeader(log, "FCFS", initFloor, travelTime, cap);

    sortByRequestTime(requests);
    int curFloor = initFloor;
    int curTime = 0;
    if (!requests.empty() && curTime < requests[0].requestTime)
        curTime = requests[0].requestTime;

    for (auto &r : requests)
    {
        if (curTime < r.requestTime) curTime = r.requestTime;
        int move1 = absInt(r.startFloor - curFloor) * travelTime;
        int move2 = absInt(r.destFloor - r.startFloor) * travelTime;
        curTime += move1 + move2;
        S.totalTravelTime += move1 + move2;
        S.servedOrder.push_back(r.id);
        S.perRequestTurnaround.push_back(curTime - r.requestTime);
        curFloor = r.destFloor;
    }

    S.makespan = (!requests.empty()) ? (curTime - requests[0].requestTime) : 0;
    std::fprintf(log, "TOTAL travel=%d MAKESPAN=%d\n",
                 S.totalTravelTime, S.makespan);
    std::fclose(log);
    return S;
}

// ==========================================================
// 2️⃣ SSTF (Shortest-Seek-Time-First)
// ==========================================================
RunStats ElevatorScheduler::runSSTF(std::vector<Request> requests,
                                    int totalFloors, int travelTime,
                                    int initFloor, int cap,
                                    const std::string &file)
{
    (void)totalFloors; (void)cap;
    RunStats S;
    FILE *log = std::fopen(file.c_str(), "w");
    if (!log) return S;
    writeHeader(log, "SSTF", initFloor, travelTime, cap);

    std::vector<int> served(requests.size(), 0);
    int remaining = (int)requests.size();

    int earliest = INT_MAX;
    for (auto &r : requests) if (r.requestTime < earliest) earliest = r.requestTime;
    int curTime = (earliest == INT_MAX) ? 0 : earliest;
    int curFloor = initFloor;

    while (remaining > 0)
    {
        int pick = -1, bestDist = INT_MAX;

        for (size_t i = 0; i < requests.size(); ++i)
        {
            if (!served[i] && requests[i].requestTime <= curTime)
            {
                int dist = absInt(requests[i].startFloor - curFloor);
                if (dist < bestDist) { bestDist = dist; pick = (int)i; }
            }
        }

        if (pick == -1)
        {
            int nextT = minUnservedRequestTime(requests, served);
            if (nextT < 0) break;
            curTime = nextT;
            continue;
        }

        auto r = requests[pick];
        int move1 = absInt(r.startFloor - curFloor) * travelTime;
        int move2 = absInt(r.destFloor - r.startFloor) * travelTime;
        curTime += move1 + move2;
        S.totalTravelTime += move1 + move2;
        S.servedOrder.push_back(r.id);
        S.perRequestTurnaround.push_back(curTime - r.requestTime);
        curFloor = r.destFloor;
        served[pick] = 1;
        --remaining;
    }

    S.makespan = (!requests.empty() && earliest != INT_MAX)
                     ? (curTime - earliest)
                     : 0;
    std::fprintf(log, "TOTAL travel=%d MAKESPAN=%d\n",
                 S.totalTravelTime, S.makespan);
    std::fclose(log);
    return S;
}

// ==========================================================
// 3️⃣ SWEEP (Directional / SCAN-like)
// ==========================================================
RunStats ElevatorScheduler::runSweep(std::vector<Request> requests,
                                     int totalFloors, int travelTime,
                                     int initFloor, int cap,
                                     const std::string &file)
{
    (void)totalFloors; (void)cap;
    RunStats S;
    FILE *log = std::fopen(file.c_str(), "w");
    if (!log) return S;
    writeHeader(log, "SWEEP", initFloor, travelTime, cap);

    std::vector<int> served(requests.size(), 0);
    int remaining = (int)requests.size();

    int earliest = INT_MAX;
    for (auto &r : requests) if (r.requestTime < earliest) earliest = r.requestTime;

    int curTime = (earliest == INT_MAX) ? 0 : earliest;
    int curFloor = initFloor;
    int dir = 1; // 1 = up, -1 = down

    while (remaining > 0)
    {
        int pick = -1, bestDist = INT_MAX;

        for (size_t i = 0; i < requests.size(); ++i)
        {
            if (!served[i] && requests[i].requestTime <= curTime)
            {
                int df = requests[i].startFloor - curFloor;
                if ((dir == 1 && df >= 0) || (dir == -1 && df <= 0))
                {
                    int dist = absInt(df);
                    if (dist < bestDist) { bestDist = dist; pick = (int)i; }
                }
            }
        }

        if (pick == -1)
        {
            dir *= -1;
            int nextT = minUnservedRequestTime(requests, served);
            if (nextT < 0) break;
            curTime = nextT;
            continue;
        }

        auto r = requests[pick];
        int move1 = absInt(r.startFloor - curFloor) * travelTime;
        int move2 = absInt(r.destFloor - r.startFloor) * travelTime;
        curTime += move1 + move2;
        S.totalTravelTime += move1 + move2;
        S.servedOrder.push_back(r.id);
        S.perRequestTurnaround.push_back(curTime - r.requestTime);
        curFloor = r.destFloor;
        served[pick] = 1;
        --remaining;
    }

    S.makespan = (!requests.empty() && earliest != INT_MAX)
                     ? (curTime - earliest)
                     : 0;
    std::fprintf(log, "TOTAL travel=%d MAKESPAN=%d\n",
                 S.totalTravelTime, S.makespan);
    std::fclose(log);
    return S;
}
