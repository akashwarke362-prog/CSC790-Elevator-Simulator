/**
 * CSC232 - Data Structures
 * Missouri State University, Fall 2025
 *
 * @file    main.cpp
 * @author  Akash Warke
 * @brief   Function that creates a new array twice the size of the input,
 *          copies over the old values, zero-fills the rest, and updates the
 *          caller's pointer to the new array.
 */

#include <iostream>

static void double_and_copy( int *& arr, int & n )
{
    int new_n{ n * 2 };
    int * bigger{ new int[ new_n ] };

    for ( int i{ 0 }; i < n; ++i )
    {
        bigger[ i ] = arr[ i ];
    }
    for ( int i{ n }; i < new_n; ++i )
    {
        bigger[ i ] = 0;
    }

    delete [ ] arr;
    arr = bigger;
    n = new_n;
}

int main( )
{
    int n{ 5 };
    int * a{ new int[ n ]{ 1, 2, 3, 4, 5 } };

    std::cout << "Before: n=" << n << " : ";
    for ( int i{ 0 }; i < n; ++i ) std::cout << a[ i ] << ( ( i + 1 == n ) ? '\n' : ' ' );

    double_and_copy( a, n );

    std::cout << "After:  n=" << n << " : ";
    for ( int i{ 0 }; i < n; ++i ) std::cout << a[ i ] << ( ( i + 1 == n ) ? '\n' : ' ' );

    delete [ ] a;
    return 0;
}