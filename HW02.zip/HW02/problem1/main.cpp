/**
 * CSC232 - Data Structures
 * Missouri State University, Fall 2025
 *
 * @file    main.cpp
 * @author  Akash Warke
 * @brief   Displays all perfect numbers from 1 to 1000.
 */

#include <iostream>

// -----------------------------------------------------------------------------
// Checks if a given integer is a perfect number.
// A perfect number is equal to the sum of its proper divisors (excluding itself).
// -----------------------------------------------------------------------------
static bool is_perfect( int n )
{
    if ( n < 2 )
    {
        return false;
    }

    int sum{ 1 };

    for ( int d{ 2 }; d * d <= n; ++d )
    {
        if ( n % d == 0 )
        {
            sum += d;
            int q{ n / d };

            if ( q != d )
            {
                sum += q;
            }
        }
    }

    return sum == n;
}

// -----------------------------------------------------------------------------
// Entry point: prints all perfect numbers from 1 through 1000.
// -----------------------------------------------------------------------------
int main( )
{
    std::cout << "Perfect numbers from 1 to 1000:\n";

    for ( int n{ 2 }; n <= 1000; ++n )
    {
        if ( is_perfect( n ) )
        {
            std::cout << n << '\n';
        }
    }

    return 0;
}
