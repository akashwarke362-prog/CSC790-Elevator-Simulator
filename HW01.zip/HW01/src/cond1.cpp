/**
 * Elevator Simulator — Logic 1: request_time(earliest first)
 * Author: Akash Warke
 */

#include "ElevetorSimulator.h"

void cond1(struct Request reqs[], int n, int total_floors,
              int travel_time, int initial_floor, int capacity)
{
    (void)total_floors; (void)capacity;

    FILE *log = fopen("log1_by_req_time.txt", "w");
    if (!log) { fprintf(stderr, "Cannot open log1_by_req_time.txt\n"); return; }

    sort_by_request_time(reqs, n);

    int current_floor = initial_floor;
    int current_time  = 0;
    if (n > 0 && current_time < reqs[0].request_time) current_time = reqs[0].request_time;

    fprintf(log, "=== by_req_time LOG ===\n");
    fprintf(log, "initial_floor=%d travel_time_per_floor=%d capacity=%d\n\n",
            initial_floor, travel_time, capacity);

    int total_travel = 0;

    for (int i = 0; i < n; ++i) {
        struct Request r = reqs[i];

        if (current_time < r.request_time) {
            fprintf(log, "[t=%d] idle until t=%d (next request)\n", current_time, r.request_time);
            current_time = r.request_time;
        }

        int to_pick = abs_i(r.start_floor - current_floor);
        int move1   = to_pick * travel_time;
        current_time += move1;
        total_travel += move1;

        fprintf(log, "[t=%d] pickup Req#%d at floor %d (from %d, travel=%d)\n",
                current_time, r.id, r.start_floor, current_floor, move1);

        int to_drop = abs_i(r.dest_floor - r.start_floor);
        int move2   = to_drop * travel_time;
        current_time += move2;
        total_travel += move2;

        int turnaround = current_time - r.request_time;

        fprintf(log, "[t=%d] drop   Req#%d at floor %d (travel=%d) | per-request time=%d\n",
                current_time, r.id, r.dest_floor, move2, turnaround);

        current_floor = r.dest_floor;
    }

    int makespan = (n > 0) ? (current_time - reqs[0].request_time) : 0;
    fprintf(log, "\nTOTAL travel_time=%d  |  MAKESPAN=%d\n", total_travel, makespan);

    fclose(log);
    printf("request_time finished. See log1_by_req_time.txt\n");
}
