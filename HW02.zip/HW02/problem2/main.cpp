/**
 * CSC232 - Data Structures
 * Missouri State University, Fall 2025
 *
 * @file    main.cpp
 * @author  Akash Warke
 * @brief   Swaps two dynamically allocated integer arrays having random sizes
 *          between 10 and 20. The first array contains values in [30, 60];
 *          the second in [70, 100].
 */

#include <iostream>
#include <random>
#include <chrono>

static void swap_arrays( int *& a, int & nA, int *& b, int & nB )
{
    int * tptr{ a };
    a = b;
    b = tptr;

    int tsize{ nA };
    nA = nB;
    nB = tsize;
}

static void fill_random( int * arr, int n, int lo, int hi, std::mt19937 & rng )
{
    std::uniform_int_distribution<int> dist( lo, hi );
    for ( int i{ 0 }; i < n; ++i )
    {
        arr[ i ] = dist( rng );
    }
}

int main( )
{
    std::mt19937 rng( static_cast<unsigned>(
        std::chrono::high_resolution_clock::now( ).time_since_epoch( ).count( ) ) );

    std::uniform_int_distribution<int> size_dist( 10, 20 );
    int nA{ size_dist( rng ) };
    int nB{ size_dist( rng ) };

    int * A{ new int[ nA ] };
    int * B{ new int[ nB ] };

    fill_random( A, nA, 30, 60, rng );
    fill_random( B, nB, 70, 100, rng );

    std::cout << "Before swap:\nA(" << nA << "): ";
    for ( int i{ 0 }; i < nA; ++i ) std::cout << A[ i ] << ( ( i + 1 == nA ) ? '\n' : ' ' );

    std::cout << "B(" << nB << "): ";
    for ( int i{ 0 }; i < nB; ++i ) std::cout << B[ i ] << ( ( i + 1 == nB ) ? '\n' : ' ' );

    swap_arrays( A, nA, B, nB );

    std::cout << "\nAfter swap:\nA(" << nA << "): ";
    for ( int i{ 0 }; i < nA; ++i ) std::cout << A[ i ] << ( ( i + 1 == nA ) ? '\n' : ' ' );

    std::cout << "B(" << nB << "): ";
    for ( int i{ 0 }; i < nB; ++i ) std::cout << B[ i ] << ( ( i + 1 == nB ) ? '\n' : ' ' );

    delete [ ] A;
    delete [ ] B;
    return 0;
}
