#include "SimUtils.h"
#include <algorithm>
#include <cstdlib>

namespace SimUtils
{
    int absInt(int x) { return x < 0 ? -x : x; }

    int randomInt(int lo, int hi)
    {
        if (hi < lo) std::swap(lo, hi);
        return lo + (std::rand() % (hi - lo + 1));
    }

    void generateRequests(std::vector<Request> &requests, int n, int totalFloors, int seed)
    {
        requests.clear();
        if (seed != 0) std::srand(static_cast<unsigned>(seed));

        for (int i = 0; i < n; ++i)
        {
            int t = randomInt(0, 30);
            int s = randomInt(0, totalFloors - 1);
            int d = randomInt(0, totalFloors - 1);
            if (d == s) d = (d + 1) % totalFloors;
            requests.emplace_back(i + 1, t, s, d);
        }
    }

    void sortByRequestTime(std::vector<Request> &requests)
    {
        std::sort(requests.begin(), requests.end(),
                  [](const Request &a, const Request &b) { return a.requestTime < b.requestTime; });
    }

    int minUnservedRequestTime(const std::vector<Request> &requests, const std::vector<int> &served)
    {
        int best = 1e9;
        for (size_t i = 0; i < requests.size(); ++i)
            if (!served[i] && requests[i].requestTime < best) best = requests[i].requestTime;
        return (best == 1e9) ? -1 : best;
    }
}
