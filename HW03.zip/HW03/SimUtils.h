#ifndef SIMUTILS_H
#define SIMUTILS_H

#include <vector>
#include "Request.h"

// General utility functions for simulation.
namespace SimUtils
{
    int absInt(int x);
    int randomInt(int lo, int hi);
    void generateRequests(std::vector<Request> &requests, int n, int totalFloors, int seed);
    void sortByRequestTime(std::vector<Request> &requests);
    int minUnservedRequestTime(const std::vector<Request> &requests, const std::vector<int> &served);
}

#endif // SIMUTILS_H
