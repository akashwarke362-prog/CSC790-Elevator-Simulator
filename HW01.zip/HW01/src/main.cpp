/**
 * Elevator Simulator — Main
 * Author: Akash Warke
 */

#include "ElevetorSimulator.h"

static int clamp_i(int v, int lo, int hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

int main(void) {
    int total_floors, capacity, travel_time, initial_floor, n_requests;

    srand((unsigned)time(NULL));

    printf("Enter total floors (>=2): ");
    if (scanf("%d", &total_floors) != 1 || total_floors < 2) { printf("Invalid floors.\n"); return 1; }

    printf("Enter elevator capacity (>=1): ");
    if (scanf("%d", &capacity) != 1 || capacity < 1) { printf("Invalid capacity.\n"); return 1; }

    printf("Enter travel time between adjacent floors (seconds, >=1): ");
    if (scanf("%d", &travel_time) != 1 || travel_time < 1) { printf("Invalid travel time.\n"); return 1; }

    printf("Enter initial floor (0..%d): ", total_floors - 1);
    if (scanf("%d", &initial_floor) != 1) { printf("Invalid initial floor.\n"); return 1; }
    initial_floor = clamp_i(initial_floor, 0, total_floors - 1);

    printf("Enter number of requests (1..%d): ", MAX_REQUESTS);
    if (scanf("%d", &n_requests) != 1 || n_requests < 1 || n_requests > MAX_REQUESTS) {
        printf("Invalid number of requests.\n"); 
        return 1;
    }

    struct Request base[MAX_REQUESTS];
    generate_requests(base, n_requests, total_floors);
    print_requests(base, n_requests);

    printf("\nSelect Algorithm:\n");
    printf("1.by request time\n");
    printf("2. nearest pickup among available\n");
    printf("3. directional sweep\n");
    printf("Choice: ");

    int choice = 0;
    if (scanf("%d", &choice) != 1) { printf("Invalid choice.\n"); return 1; }

    /* copy so each run can reorder/mutate safely */
    struct Request requests[MAX_REQUESTS];
    copy_requests(base, requests, n_requests);

    switch (choice) {
        case 1:
            cond1(requests, n_requests, total_floors, travel_time, initial_floor, capacity);
            break;
        case 2:
            cond2(requests, n_requests, total_floors, travel_time, initial_floor, capacity);
            break;
        case 3:
            cond3(requests, n_requests, total_floors, travel_time, initial_floor, capacity);
            break;
        default:
            printf("Invalid choice.\n");
            return 1;
    }

    printf("\nLogs written: log1_by_req_time.txt / log2_nearest_pickup.txt / log3_directional_sweep.txt\n");
    return 0;
}
