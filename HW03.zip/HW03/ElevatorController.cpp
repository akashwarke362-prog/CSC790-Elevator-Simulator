#include "ElevatorController.h"
#include <iostream>

ElevatorController::ElevatorController(int i, int f, int t, int c, Algorithm a)
    : id(i), initialFloor(f), travelTime(t), capacity(c), algorithm(a) {}

void ElevatorController::addRequest(const Request &req) { requests.push_back(req); }
void ElevatorController::setRequests(std::vector<Request> reqs) { requests = std::move(reqs); }
const std::vector<Request> &ElevatorController::getRequests() const { return requests; }

void ElevatorController::processRequests(int totalFloors, const std::string &prefix)
{
    std::string file = prefix + "_elevator" + std::to_string(id) + ".txt";
    switch (algorithm)
    {
    case Algorithm::FCFS:  stats = ElevatorScheduler::runFCFS(requests, totalFloors, travelTime, initialFloor, capacity, file); break;
    case Algorithm::SSTF:  stats = ElevatorScheduler::runSSTF(requests, totalFloors, travelTime, initialFloor, capacity, file); break;
    case Algorithm::SWEEP: stats = ElevatorScheduler::runSweep(requests, totalFloors, travelTime, initialFloor, capacity, file); break;
    }
}

void ElevatorController::printSummary() const
{
    std::string name = (algorithm == Algorithm::FCFS ? "FCFS" :
                        algorithm == Algorithm::SSTF ? "SSTF" : "SWEEP");
    std::cout << "Elevator " << id << " (" << name << "): "
              << requests.size() << " requests, travel "
              << stats.totalTravelTime << "s, makespan "
              << stats.makespan << "s\n";
}
