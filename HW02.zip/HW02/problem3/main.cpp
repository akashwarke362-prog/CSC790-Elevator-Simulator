/**
 * CSC232 - Data Structures
 * Missouri State University, Fall 2025
 *
 * @file    main.cpp
 * @author  Akash Warke
 * @brief   Reads integers and displays them in reverse order.
 *          Constraint: all variables in the code are pointers.
 */

#include <iostream>

int main( )
{
    int * capacity{ new int( 8 ) };
    int * size{ new int( 0 ) };
    int * arr{ new int[ *capacity ] };

    std::cout << "Enter integers (Ctrl+D / Ctrl+Z to end):\n";

    int * x{ new int };
    while ( std::cin >> *x )
    {
        if ( *size == *capacity )
        {
            int * new_cap{ new int( *capacity * 2 ) };
            int * tmp{ new int[ *new_cap ] };
            for ( int * i{ new int( 0 ) }; *i < *size; ++( *i ) )
            {
                tmp[ *i ] = arr[ *i ];
            }
            delete [ ] arr;
            arr = tmp;
            *capacity = *new_cap;
            delete new_cap;
        }

        arr[ *size ] = *x;
        ++( *size );
    }

    std::cout << "Reverse order:\n";
    for ( int * i{ new int( ( *size ) - 1 ) }; *i >= 0; --( *i ) )
    {
        std::cout << arr[ *i ] << ( ( *i == 0 ) ? '\n' : ' ' );
        if ( *i == 0 )
        {
            break;
        }
    }

    delete [ ] arr;
    delete capacity;
    delete size;
    delete x;
    return 0;
}