/**
 * Elevator Simulator — Header
 * Author: Akash Warke
 */

#ifndef ELEVETORSIMULATOR_H
#define ELEVETORSIMULATOR_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

#define MAX_REQUESTS 200

/* ---- Core data type ---- */
struct Request {
    int id;            /* 1..n */
    int request_time;  /* seconds, when call is made */
    int start_floor;
    int dest_floor;
};

/* ---- Shared helpers (implemented in elevator_utils.cpp) ---- */
void generate_requests(struct Request a[], int n, int total_floors);
void print_requests(const struct Request a[], int n);
void copy_requests(const struct Request src[], struct Request dst[], int n);

int  abs_i(int x);
void sort_by_request_time(struct Request a[], int n);
int  min_unserved_request_time(const struct Request a[], const int served[], int n);

/* ---- Algorithms ---- */
void cond1(struct Request reqs[], int n, int total_floors,
              int travel_time, int initial_floor, int capacity);

void cond2(struct Request reqs[], int n, int total_floors,
              int travel_time, int initial_floor, int capacity);

void cond3(struct Request reqs[], int n, int total_floors,
              int travel_time, int initial_floor, int capacity);

#endif /* ELEVETORSIMULATOR_H */