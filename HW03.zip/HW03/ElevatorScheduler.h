#ifndef ELEVATORSCHEDULER_H
#define ELEVATORSCHEDULER_H

#include <vector>
#include <string>
#include "Request.h"

// Supported scheduling algorithms
enum class Algorithm
{
    FCFS = 1,   // First-Come, First-Served
    SSTF = 2,   // Shortest-Seek-Time-First
    SWEEP = 3   // Directional sweep / SCAN
};

// Holds summary statistics for one algorithm run
struct RunStats
{
    int totalTravelTime = 0;
    int makespan = 0;
    std::vector<int> servedOrder;
    std::vector<int> perRequestTurnaround;
};

// ------------------------------------------------------------
// ElevatorScheduler
// ------------------------------------------------------------
// Contains the three scheduling algorithms reused from Homework-1.
// Each method simulates request handling and writes a log file.
// ------------------------------------------------------------
class ElevatorScheduler
{
public:
    // Pass-by-value signatures (match ElevatorController.cpp calls)
    static RunStats runFCFS(std::vector<Request> requests,
                            int totalFloors, int travelTime,
                            int initialFloor, int capacity,
                            const std::string &logFile);

    static RunStats runSSTF(std::vector<Request> requests,
                            int totalFloors, int travelTime,
                            int initialFloor, int capacity,
                            const std::string &logFile);

    static RunStats runSweep(std::vector<Request> requests,
                             int totalFloors, int travelTime,
                             int initialFloor, int capacity,
                             const std::string &logFile);
};

#endif // ELEVATORSCHEDULER_H
