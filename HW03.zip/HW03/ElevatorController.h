#ifndef ELEVATORCONTROLLER_H
#define ELEVATORCONTROLLER_H

#include <vector>
#include <string>
#include "Request.h"
#include "ElevatorScheduler.h"

// Represents one physical elevator.
class ElevatorController
{
public:
    ElevatorController(int id, int initFloor, int travelTime,
                       int capacity, Algorithm algo);

    void addRequest(const Request &req);
    void setRequests(std::vector<Request> reqs);
    const std::vector<Request> &getRequests() const;

    void processRequests(int totalFloors, const std::string &logPrefix);
    void printSummary() const;

    int getId() const { return id; }
    Algorithm getAlgorithm() const { return algorithm; }
    const RunStats &getStats() const { return stats; }

private:
    int id, initialFloor, travelTime, capacity;
    Algorithm algorithm;
    std::vector<Request> requests;
    RunStats stats;
};

#endif // ELEVATORCONTROLLER_H
