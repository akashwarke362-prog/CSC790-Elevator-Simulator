#include "BuildingManager.h"
#include "SimUtils.h"
#include <iostream>
#include <limits>

BuildingManager::BuildingManager(int floors) : totalFloors(floors) {}

void BuildingManager::configureElevators(int count, const std::vector<int> &floors,
                                         const std::vector<int> &times,
                                         const std::vector<int> &caps,
                                         const std::vector<Algorithm> &algos)
{
    elevators.clear();
    for (int i = 0; i < count; ++i)
        elevators.emplace_back(i + 1, floors[i], times[i], caps[i], algos[i]);
}

void BuildingManager::setRequests(const std::vector<Request> &reqs)
{
    allRequests = reqs;
}

void BuildingManager::assignRequestsGreedy()
{
    for (const auto &r : allRequests)
    {
        int bestIdx = 0, bestDist = std::numeric_limits<int>::max();
        for (size_t i = 0; i < elevators.size(); ++i)
        {
            int est = static_cast<int>((i * (totalFloors - 1)) /
                                       (elevators.size() > 1 ? elevators.size() - 1 : 1));
            int dist = SimUtils::absInt(r.startFloor - est);
            if (dist < bestDist) { bestDist = dist; bestIdx = static_cast<int>(i); }
        }
        elevators[bestIdx].addRequest(r);
    }
}

void BuildingManager::runAll(const std::string &prefix)
{
    for (auto &e : elevators)
        e.processRequests(totalFloors, prefix);
}

void BuildingManager::printSummary() const
{
    std::cout << "\n=== Simulation Summary ===\n";
    for (const auto &e : elevators)
        e.printSummary();
}
