#ifndef REQUEST_H
#define REQUEST_H

// Represents a single passenger ride request.
class Request
{
public:
    int id;           // unique request number
    int requestTime;  // time when request was made (seconds)
    int startFloor;   // pickup floor
    int destFloor;    // destination floor

    Request(int i = 0, int t = 0, int s = 0, int d = 0)
        : id(i), requestTime(t), startFloor(s), destFloor(d) {}
};

#endif // REQUEST_H
